package com.example.miaplicacion;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;

import androidx.appcompat.app.AppCompatActivity;
import androidx.viewpager.widget.ViewPager;

import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.tabs.TabLayout;

import cn.pedant.SweetAlert.SweetAlertDialog;

public class login extends AppCompatActivity {

    TabLayout tabLayout;
    ViewPager viewPager;
    private String url, url1, url2;
    FloatingActionButton fb,google,twitter, siguiente;;
    float v =0;
    @Override
    protected void onCreate(Bundle savedInstanceState){
        super.onCreate (savedInstanceState);
        setContentView(R.layout.activity_login);

        siguiente = findViewById (R.id.pasar);
        fb = findViewById (R.id.fab_facebook);
        twitter = findViewById (R.id.fab_twitter);
        google = findViewById (R.id.fab_google);
        url = "https://twitter.com/?lang=es";
        url1 = "https://www.facebook.com/";
        url2 = "https://accounts.google.com/ServiceLogin/signinchooser?service=mail&passive=1209600&osid=1&continue=https%3A%2F%2Fmail.google.com%2Fmail%2Fu%2F0%2F%3Ftab%3Drm%26ogbl&followup=https%3A%2F%2Fmail.google.com%2Fmail%2Fu%2F0%2F%3Ftab%3Drm%26ogbl&emr=1&flowName=GlifWebSignIn&flowEntry=ServiceLogin";

        fb.setOnClickListener (new View.OnClickListener () {
            @Override
            public void onClick(View view) {

                Uri uri = Uri.parse (url1);
                Intent intent = new Intent(Intent.ACTION_VIEW, uri);
                startActivity (intent);

            }
        });

        google.setOnClickListener (new View.OnClickListener () {
            @Override
            public void onClick(View view) {

                Uri uri = Uri.parse (url2);
                Intent intent = new Intent(Intent.ACTION_VIEW, uri);
                startActivity (intent);

            }
        });

        twitter.setOnClickListener (new View.OnClickListener () {
            @Override
            public void onClick(View view) {

                Uri uri = Uri.parse (url);
                Intent intent = new Intent(Intent.ACTION_VIEW, uri);
                startActivity (intent);

            }
        });

        siguiente.setOnClickListener (new View.OnClickListener () {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(login.this, InicioActivity.class);
                startActivity(intent);

            }
        });

        tabLayout = findViewById (R.id.tab_layout);
        viewPager = findViewById (R.id.view_pager);
        fb = findViewById (R.id.fab_facebook);
        google= findViewById (R.id.fab_google);
        twitter = findViewById (R.id.fab_twitter);


        tabLayout.addTab(tabLayout.newTab ().setText ("Login"));
        tabLayout.addTab(tabLayout.newTab ().setText ("Singup"));
        tabLayout.setTabGravity (TabLayout.GRAVITY_FILL);

        final LoginAdapter adapter = new LoginAdapter (getSupportFragmentManager (), this,tabLayout.getTabCount ());
        viewPager.setAdapter (adapter);

        viewPager.addOnPageChangeListener (new TabLayout.TabLayoutOnPageChangeListener (tabLayout));

        fb.setTranslationY (300);
        google.setTranslationY (300);
        twitter.setTranslationY (300);
        tabLayout.setTranslationY (300);

        fb.setAlpha (v);
        google.setAlpha (v);
        twitter.setAlpha (v);
        tabLayout.setAlpha (v);


        fb.animate ().translationY (0).alpha (1).setDuration (1000).setStartDelay (400).start ();
        google.animate ().translationY (0).alpha (1).setDuration (1000).setStartDelay (600).start ();
        twitter.animate ().translationY (0).alpha (1).setDuration (1000).setStartDelay (800).start ();
        twitter.animate ().translationY (0).alpha (1).setDuration (1000).setStartDelay (100).start ();


    }
    @Override
    public void onBackPressed() {
        new SweetAlertDialog(this, SweetAlertDialog.WARNING_TYPE).setTitleText("Has apretado el boton salir")
                .setContentText("¿Quieres cerrar la aplicación?")
                .setCancelText("No, Cancelar!").setConfirmText("Sí, Cerrar")
                .showCancelButton(true).setCancelClickListener(sDialog -> {
            sDialog.dismissWithAnimation();
            new SweetAlertDialog(this, SweetAlertDialog.ERROR_TYPE).setTitleText("Operación cancelada")
                    .setContentText("No saliste de la app")
                    .show();
        }).setConfirmClickListener(sweetAlertDialog -> {
            sweetAlertDialog.dismissWithAnimation();
            System.exit(0);
        }).show();
    }
}