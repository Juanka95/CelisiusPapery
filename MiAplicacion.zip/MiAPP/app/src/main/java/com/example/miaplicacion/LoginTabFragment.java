package com.example.miaplicacion;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;

import com.example.miaplicacion.entity.service.Usuario;
import com.example.miaplicacion.utils.DateSerializer;
import com.example.miaplicacion.utils.TimeSerializer;
import com.example.miaplicacion.viewmodel.UsuarioViewModel;
import com.google.android.material.textfield.TextInputLayout;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.reflect.TypeToken;

import java.sql.Date;
import java.sql.Time;

public class LoginTabFragment extends Fragment {

    private EditText email, pass;
    private TextInputLayout emailtxt, passtxt;
    Button login;
    float v =0;
    private UsuarioViewModel viewModel;

 @Override
 public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState){

     ViewGroup root = (ViewGroup) inflater.inflate (R.layout.login_tab_fragment, container, false);

     emailtxt = root.findViewById (R.id.txtInputUsuario);
     passtxt = root.findViewById (R.id.txtInputPassword);
     email = root.findViewById (R.id.email);
     pass = root.findViewById (R.id.contra);
    login = root.findViewById (R.id.siguiente);


    email.setTranslationX (800);
    pass.setTranslationX (800);
    login.setTranslationX (800);


    email.setAlpha (v);
     pass.setAlpha (v);
     login.setAlpha (v);

     email.animate ().translationX (0).alpha (1).setDuration (800).setStartDelay (300).start ();
     pass.animate ().translationX (0).alpha (1).setDuration (800).setStartDelay (500).start ();
     login.animate ().translationX (0).alpha (1).setDuration (800).setStartDelay (500).start ();

     this.initViewModel();

     login.setOnClickListener (new View.OnClickListener () {
         @Override
         public void onClick(View view) {
             try {
                 if (validar()) {
                     viewModel.login(email.getText().toString(), pass.getText().toString()).observe(getActivity (), response -> {
                         if (response.getRpta() == 1) {
                             //Toast.makeText(this, response.getMessage(), Toast.LENGTH_SHORT).show();
                             toastCorrecto(response.getMessage());
                             Usuario u = response.getBody();
                             SharedPreferences preferences = PreferenceManager.getDefaultSharedPreferences(getActivity ());
                             SharedPreferences.Editor editor = preferences.edit();
                             final Gson g = new GsonBuilder ()
                                     .registerTypeAdapter(Date.class, new DateSerializer ())
                                     .registerTypeAdapter(Time.class, new TimeSerializer ())
                                     .create();
                             editor.putString("UsuarioJson", g.toJson(u, new TypeToken<Usuario> () {
                             }.getType()));
                             editor.apply();
                             email.setText("");
                             pass.setText("");
                             startActivity(new Intent(getActivity (), InicioActivity.class));
                         } else {
                             toastIncorrecto("Credenciales Inválidas");
                         }
                     });
                 } else {
                     toastIncorrecto("Por favor, complete todos los campos.");
                 }
             } catch (Exception e) {
                 toastIncorrecto("Se ha producido un error al intentar loguearte : " + e.getMessage());
             }
         }
     });



     email.addTextChangedListener(new TextWatcher () {
         @Override
         public void beforeTextChanged(CharSequence s, int start, int count, int after) {

         }

         @Override
         public void onTextChanged(CharSequence s, int start, int before, int count) {
             emailtxt.setErrorEnabled(false);
         }

         @Override
         public void afterTextChanged(Editable s) {

         }
     });
     pass.addTextChangedListener(new TextWatcher() {
         @Override
         public void beforeTextChanged(CharSequence s, int start, int count, int after) {

         }

         @Override
         public void onTextChanged(CharSequence s, int start, int before, int count) {
             passtxt.setErrorEnabled(false);
         }

         @Override
         public void afterTextChanged(Editable s) {

         }
     });

     return root;
 }

    private void init() {



    }

    private void initViewModel() {
        viewModel = new ViewModelProvider (this).get (UsuarioViewModel.class);
    }
    public void toastCorrecto(String msg) {
        LayoutInflater layoutInflater = getLayoutInflater();
        View view = layoutInflater.inflate(R.layout.custom_toast_ok, (ViewGroup) getView ().findViewById(R.id.ll_custom_toast_ok));
        TextView txtMensaje = view.findViewById(R.id.txtMensajeToast1);
        txtMensaje.setText(msg);

        Toast toast = new Toast(getActivity ());
        toast.setGravity(Gravity.CENTER_VERTICAL | Gravity.BOTTOM, 0, 200);
        toast.setDuration(Toast.LENGTH_LONG);
        toast.setView(view);
        toast.show();
    }

    public void toastIncorrecto(String msg) {
        LayoutInflater layoutInflater = getLayoutInflater();
        View view = layoutInflater.inflate(R.layout.custom_toast_error, (ViewGroup) getView ().findViewById(R.id.ll_custom_toast_error));
        TextView txtMensaje = view.findViewById(R.id.txtMensajeToast2);
        txtMensaje.setText(msg);

        Toast toast = new Toast(getActivity ());
        toast.setGravity(Gravity.CENTER_VERTICAL | Gravity.BOTTOM, 0, 200);
        toast.setDuration(Toast.LENGTH_LONG);
        toast.setView(view);
        toast.show();
    }

    private boolean validar() {

        boolean retorno = true;
        String usuario, password;
        usuario = email.getText().toString();
        password = pass.getText().toString();
        if (usuario.isEmpty()) {
            emailtxt.setError("Ingrese su usario y/o correo electrónico");
            retorno = false;
        } else {
            emailtxt.setErrorEnabled(false);
        }
        if (password.isEmpty()) {
            passtxt.setError("Ingrese su contraseña");
            retorno = false;
        } else {
            passtxt.setErrorEnabled(false);
        }
        return retorno;
    }

    @Override
    public void onStart() {
        super.onStart();
        SharedPreferences preferences = PreferenceManager.getDefaultSharedPreferences(getActivity ());
        String pref = preferences.getString("UsuarioJson", "");
        if(!pref.equals("")){
            toastCorrecto("Se detecto una sesión activa, el login será omitido!");
            this.startActivity(new Intent(getActivity (), InicioActivity.class));
            getActivity ().overridePendingTransition(R.anim.left_in, R.anim.left_out);
        }
    }
}
