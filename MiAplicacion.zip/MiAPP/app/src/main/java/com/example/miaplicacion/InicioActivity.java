package com.example.miaplicacion;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.navigation.NavController;
import androidx.navigation.Navigation;
import androidx.navigation.ui.AppBarConfiguration;
import androidx.navigation.ui.NavigationUI;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.miaplicacion.adapter.ListAdapter;
import com.example.miaplicacion.api.ConfigAPI;
import com.example.miaplicacion.databinding.ActivityInicioBinding;
import com.example.miaplicacion.entity.service.Usuario;
import com.example.miaplicacion.utils.DateSerializer;
import com.example.miaplicacion.utils.TimeSerializer;
import com.google.android.material.navigation.NavigationView;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.squareup.picasso.OkHttp3Downloader;
import com.squareup.picasso.Picasso;

import java.sql.Date;
import java.sql.Time;
import java.util.ArrayList;
import java.util.List;

import de.hdodenhof.circleimageview.CircleImageView;

public  class InicioActivity extends AppCompatActivity {

    List<ListElement> elements;
    private AppBarConfiguration mAppBarConfiguration;
    private ActivityInicioBinding binding;
    private String url;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate (savedInstanceState);
        binding = ActivityInicioBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());
        url = "https://www.pdfdrive.com";
        setSupportActionBar(binding.appBarInicio.toolbar);
        binding.appBarInicio.fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Uri uri = Uri.parse (url);
                Intent intent = new Intent(Intent.ACTION_VIEW, uri);
                startActivity (intent);
            }
        });

        DrawerLayout drawer = binding.drawerLayout;
        NavigationView navigationView = binding.navView;
        // Passing each menu ID as a set of Ids because each
        // menu should be considered as top level destinations.
        mAppBarConfiguration = new AppBarConfiguration.Builder(
                R.id.nav_inicio, R.id.nav_mis_compras, R.id.nav_configuracion)
                .setDrawerLayout(drawer)
                .build();
        NavController navController = Navigation.findNavController(this, R.id.nav_host_fragment_content_inicio);
        NavigationUI.setupActionBarWithNavController(this, navController, mAppBarConfiguration);
        NavigationUI.setupWithNavController(navigationView, navController);
        init();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.inicio, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        switch (item.getItemId()){
            case R.id.cerrarSesion:
                this.logout();
                break;
            case R.id.bolsaCompras:
                this.mostrarBolsa();
                break;
        }
        return super.onOptionsItemSelected(item);
    }

    private void mostrarBolsa() {
        Intent i = new Intent (this, PlatillosCarritoActivity.class);
        startActivity(i);
        overridePendingTransition(R.anim.left_in, R.anim.left_out);
    }

    @SuppressLint("UnsafeExperimentalUsageError")
    private void loadData() {
        SharedPreferences sp = PreferenceManager.getDefaultSharedPreferences(this);
        final Gson g = new GsonBuilder ()
                .registerTypeAdapter(Date.class, new DateSerializer ())
                .registerTypeAdapter(Time.class, new TimeSerializer ())
                .create();
        String usuarioJson = sp.getString("UsuarioJson", null);
        if(usuarioJson != null){
            final Usuario u = g.fromJson(usuarioJson, Usuario.class);
            final View vistaHeader = binding.navView.getHeaderView(0);
            final TextView tvNombre = vistaHeader.findViewById(R.id.tvNombre),
                    tvCorreo = vistaHeader.findViewById(R.id.tvCorreo);
            final CircleImageView imgFoto = vistaHeader.findViewById(R.id.imgFotoPerfil);
            tvNombre.setText(u.getCliente().getNombreCompleto());
            tvCorreo.setText(u.getEmail());
            String url = ConfigAPI.ipJeicy + "/api/documento-almacenado/download/" + u.getCliente().getFoto().getFileName();
            final Picasso picasso = new Picasso.Builder(this)
                    .downloader(new OkHttp3Downloader (ConfigAPI.getClient()))
                    .build();
            picasso.load(url)
                    .error(R.drawable.image_not_found)
                    .into(imgFoto);
        }

    }



    @Override
    protected void onStart() {
        super.onStart();
        loadData();
    }

    //Método para cerrar sesión
    private void logout() {
        SharedPreferences preferences = PreferenceManager.getDefaultSharedPreferences(this);
        SharedPreferences.Editor editor = preferences.edit();
        editor.remove("UsuarioJson");
        editor.apply();
        this.finish();
        this.overridePendingTransition(R.anim.left_in, R.anim.left_out);
    }

    @Override
    public boolean onSupportNavigateUp() {
        NavController navController = Navigation.findNavController(this, R.id.nav_host_fragment_content_inicio);
        return NavigationUI.navigateUp(navController, mAppBarConfiguration)
                || super.onSupportNavigateUp();
    }

    @Override
    public void onBackPressed() {

    }
    public void init(){

        elements= new ArrayList<> ();
        elements.add (new ListElement (R.drawable.batman, "Batman", " Bob Kane y Bill Finger", "Bruce Wayne está a punto de llevarse una de las mayores sorpresas de su vida. Se llama Damian, es hijo suyo, y Talia al Ghul, la madre, lo ha criado para que sea el mejor asesino del mundo. Pero la llegada del muchacho no será más que el principio de una historia en la que la perfidia del Guante Negro pondrá en peligro tanto la vida como la cordura de Batman. Grant Morrison revolucionó la mitología de Batman durante una etapa inolvidable en la que participaron aliados como el Club de Héroes, villanos como el Joker… ¡y un nuevo Dúo Dinámico! Y para ello, se acompañó de dibujantes de la talla de Andy Kubert, J.H. Williams III, Frank Quitely, Chris Sprouse y Tony S. Daniel, entre otros.\n" , "95,00 € " ));
        elements.add (new ListElement (R.drawable.eluniverso, "El Universo", " Isaac Asimov", "La faceta como divulgador científico de Isaac Asimov se manifiesta con especial brillantez en esta obra, en la que no sólo expone de forma accesible todo el conjunto de certidumbres científicas sobre el Universo, sino que además reconstruye el largo camino que ha recorrido el hombre para alcanzarlas. Las diversas teorías sobre la edad de la tierra y del sistema solar se inscriben en el marco más general de la evolución de las galaxias y remiten, por último, al gran dilema todavía no resuelto: cómo fue el principio del universo y si tendrá un fin, o si, por el contrario, es eterno e infinito. La faceta como divulgador científico de Isaac Asimov se manifiesta con especial brillantez en esta obra, en la que no sólo expone de forma accesible todo el conjunto de certidumbres científicas sobre el Universo, sino que además reconstruye el largo camino que ha recorrido el hombre para alcanzarlas. Las diversas teorías sobre la edad de la tierra y del sistema solar se inscriben en el marco más general de la evolución de las galaxias y remiten, por último, al gran dilema todavía no resuelto: cómo fue el principio del universo y si tendrá un fin, o si, por el contrario, es eterno e infinito.\n", "15,15 €"));
        elements.add (new ListElement (R.drawable.igualite, "De l’excellence des hommes contre l’égalité des sexes", "François Poullain de La Barre", "Este libro es una reproducción de una obra publicada antes de 1920 y forma parte de una colección de libros reimpresos y editados por Hachette Livre, en el marco de una asociación con la Biblioteca Nacional de Francia, que brinda la oportunidad de acceder a libros antiguos y a menudo raros de los fondos patrimoniales de la BnF. Las obras de esta colección han sido digitalizadas por la BnF y se presentan en Gallica, su biblioteca digital. Al revivir estas obras a través de una colección de libros reimpresos bajo demanda, damos a todos la oportunidad de participar en la transmisión de conocimientos a los que a veces es difícil acceder. Hemos tratado de conciliar la reproducción fiel de un libro antiguo a partir de su versión digitalizada con la preocupación por una óptima comodidad de lectura. Esperamos que los trabajos de esta nueva colección le traigan completa satisfacción.\n", "9,17 €"));
        elements.add (new ListElement (R.drawable.spider_man, "Spider-man", " Stan Lee y Steve Ditko", "Spiderman es de un modo seguro el súper héroe más importante y famoso de la editorial Marvel Comics. Nacido en el 1962 para obra de Stan Lee, Spiderman es la historia del tímido estudiante Peter Parker que viene mordisco de una araña contaminada de los radios radiactivos en el curso de un experimento científico.\n", "37,95 €"));
        elements.add (new ListElement (R.drawable.paula, "Paula", " Isabel Allende", "Un autorretrato de insólita emotividad al tiempo que exquisita recreación de la sensibilidad de las mujeres de nuestra época.\n" +
                "\n" +
                "«Aquí está todo lo que debe tener un libro: oído, perspectiva, cabeza, corazón y una humanidad sin límites.»\n" +
                "The New York Times\n" +
                "\n" +
                "Cualquier libro de Isabel Allende es un acontecimiento.Paula lo es especialmente porque se trata del más conmovedor, más personal y más íntimo de todos los que ha publicado hasta la fecha.\n" +
                "\n" +
                "Cuando la gran autora chilena se encontraba en España con ocasión de la presentación deEl plan infinito, su hija entró en estado de coma. Junto al lecho de Paula, mientras seguía con angustia la evolución de su enfermedad, Isabel Allende comenzó a redactar en un cuaderno una historia de su familia y de sí misma con el propósito de regalársela a su hija una vez superara el dramático trance. Sin embargo, éste se prolongó durante meses y los apuntes de la autora acabaron convirtiéndose en este libro apasionante y revelador.\n" +
                "\n" +
                "Isabel Allende ejerce aquí su prodigioso talento narrativo para recuperar y asumir sus propias vivencias como mujer y como escritora, así como las de su familia y las de la historia reciente de su país. Autorretrato de insólita emotividad al tiempo que exquisita recreación de la sensibilidad de las mujeres de nuestra época, Paula perdura en el ánimo del lector con la intensidad de una experiencia indeleble.\n", "5 €"));
        elements.add (new ListElement (R.drawable.niebla, "El principe de la niebla", " Carlos Ruiz Zafon", "El primer gran éxito de Carlos Ruiz Zafón.\n" +
                "El nuevo hogar de los Carver, que se han mudado a la costa huyendo de la ciudad y de la guerra, está rodeado de misterio.\n" +
                "Todavía se respira el espíritu de Jacob, el hijo de los antiguos propietarios, que murió ahogado. Las extrañas circunstancias de esa muerte sólo se empiezan a aclarar con la aparición de un diabólico personaje: el Príncipe de la Niebla, capaz de conceder cualquier deseo a una persona; eso sí, a un alto precio.\n", "8,50 €"));
        elements.add (new ListElement (R.drawable.el_libro_negro_de_las_horas, "El libro negro de las horas", "Eva Gª Saenz De Urturi", "Alguien que lleva muerto cuarenta años no puede ser secuestrado y, desde luego, no puede sangrar.\n" +
                "\n" +
                "Vitoria, 2022. El exinspector Unai López de Ayala —alias Kraken— recibe una llamada anónima que cambiará lo que cree saber de su pasado familiar: tiene una semana para encontrar el legendario Libro Negro de las Horas, una joya bibliográfica exclusiva, si no, su madre, quien descansa en el cementerio desde hace décadas, morirá.\n" +
                "\n" +
                "¿Cómo es esto posible?\n" +
                "\n" +
                "Una carrera contrarreloj entre Vitoria y el Madrid de los bibliófilos para trazar el perfil criminal más importante de su vida, uno capaz de modificar el pasado, para siempre.\n" +
                "\n" +
                "\n" +
                "Me llamo Unai. Me llaman Kraken.\n" +
                "\n" +
                "Aquí termina tu caza, aquí comienza la mía.\n" +
                "\n" +
                "¿Y si tu madre fuera la mejor falsificadora de libros antiguos de la historia?\n", "19,85 €"));
        elements.add (new ListElement (R.drawable.elgrandebate, "El Grande Debate", "Yuval Levin", "En El gran debate, Yuval Levin explora las raíces históricas de la división derecha/izquierda estudiando las ideas de los dos hombres que a finales del siglo XVIII representaron mejor el origen de cada término: Edmund Burke y Thomas Paine. A través de una cuidadosa revisión de sus trabajos, Levin ofrece un examen profundo de los orígenes del conservadurismo y del progresismo y del debate filosófico que hoy todavía conforma la política moderna en Occidente. Burke y Paine fueron figuras completamente fascinantes. Ambos fueron políticos activos, versados en filosofía y dos de los escritores y pensadores más vigorosos de su época. Ambos lucharon por forjar un nuevo camino político en la tumultuosa era de la Revolución Francesa y de la Guerra de Independencia de los Estados Unidos. Y ambos propusieron dos conjuntos de ideas diferentes sobre la libertad, la igualdad, la naturaleza, la historia, la razón y la reforma, y sentaron las bases del sistema de partidos moderno y de nuestro orden político. Y al hacerlo, estos dos titanes ideológicos polemizaron sobre cuestiones morales y filosóficas, sobre la naturaleza de la vida política y sobre la mejor forma de acometer el cambio social: gradual y progresivamente (Burke), o radical y velozmente (Paine).\n", "96.00 €"));
        elements.add (new ListElement (R.drawable.elreymarcado, "El rey marcado", "Leigh Bardugo", "Enfrentado a tus demonios… o aliméntalos. Nikolai lantsov siempre ha tenido un don para conseguir lo imposible. Nadie sabe lo que tuvo que soportar durante la sangrienta guerra Civil de su país, y él pretende que siga siendo así. Ahora, con sus enemigos agolpados al otro lado de sus debilitadas fronteras, Nikolai deberá dar con la manera de surtir las Arcas de ravka, forjar nuevas alianzas y frenar la amenaza que se cierne sobre el ejército grises. Sin embargo, la magia oscura que corre por sus venas se fortalece día a día y amenaza con destruir todo lo que ha logrado. Con la ayuda de un joven monje y una legendaria general Grisha, Nikolai viajar a los lugares de ravka donde sobrevive una magia primigenia para dar con la manera de acabar con el terrible legado que habita en su interior\n", "19.00 €"));
        elements.add (new ListElement (R.drawable.elprincipito, "El principito", "Antoine De Saint-Exupery", "Fábula mítica y relato filosófico que interroga acerca de la relación del ser humano con su prójimo y con el mundo, El Principito concentra, con maravillosa simplicidad, la constante reflexión de Saint-Exupéry sobre la amistad, el amor, la responsabilidad y el sentido de la vida.\n" +
                "\n" +
                "Viví así, solo, sin nadie con quien hablar verdaderamente, hasta que tuve una avería en el desierto del Sahara, hace seis años. Algo se había roto en mi motor. Y como no tenía conmigo ni mecánico ni pasajeros, me dispuse a realizar, solo, una reparación difícil. Era, para mí, cuestión de vida o muerte. Tenía agua apenas para ocho días.\n" +
                "\n" +
                "La primera noche dormí sobre la arena a mil millas de todatierra habitada. Estaba más aislado que un náufrago sobre una balsa en medio del océano. Imaginaos, pues, mi sorpresa cuando, al romper el día, me despertó una extraña vocecita que decía:\n" +
                "\n" +
                "-Por favor..., ¡dibújame un cordero!\n" +
                "\n" +
                "-¿Eh!?\n" +
                "\n" +
                "-Dibújame un cordero...\n", "16,15 €"));
        elements.add (new ListElement (R.drawable.churchil, "Churchill", "Andrew Roberts", "La obra plantea varios aspectos de la vida de Winston Churchill poco conocidos.\n" +
                "Esta es, sin duda, la mejor biografía de Winston Churchill que se haya publicado. Andrew Roberts, considerado como el mejor historiador militar británico, ha podido utilizar para su trabajo una gran cantidad de documentos que ningún biógrafo había podido consultar con anterioridad, incluídos los diarios privados del rey Jorge VI, que se reunía regularmente con Churchill durante la guerra. La riqueza de la documentación que maneja permite a Roberts ahondar en la realidad humana del personaje, siguiendo su vida desde su infancia y la conflictiva relación con su padre hasta su declive, lo cual hace que el lector pueda «ver la segunda guerra mundial a través del prisma del resto de su vida».\n", "37,05 €"));
        ListAdapter listAdapter = new ListAdapter (elements, this, new ListAdapter.OnItemClickListener () {
            @Override
            public void onItemClick(ListElement item) {
                moveToDescription(item);
            }
        });
        RecyclerView recyclerView = findViewById (R.id.rcvPlatillosRecomendados);
        recyclerView.setHasFixedSize (true);
        recyclerView.setLayoutManager (new LinearLayoutManager (this));
        recyclerView.setAdapter (listAdapter);
    }

    public void moveToDescription(ListElement item){

        Intent intent = new Intent (this, DetallesPlatilloActivity.class);
        intent.putExtra ("ListElement", item);
        startActivity (intent);

    }

}