package com.example.miaplicacion.api;

import com.example.miaplicacion.utils.DateSerializer;
import com.example.miaplicacion.utils.TimeSerializer;
import com.facebook.stetho.okhttp3.StethoInterceptor;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

import java.sql.Date;
import java.sql.Time;
import java.util.concurrent.TimeUnit;

import okhttp3.OkHttpClient;
import okhttp3.logging.HttpLoggingInterceptor;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class ConfigAPI {

    public static final  String baseUrlE = "http://10.0.2.2:9090";
    public static final String ipJeicy= "http://192.168.1.133:9090";
    private static Retrofit retrofit;
    private static String token = "";

    private static UsuarioAPI usuarioAPI;
    private static ClienteAPI clienteAPI;
    private static DocumentoAlmacenadoAPI documentoAlmacenadoAPI;
    private static CategoriaAPI categoriaAPI;
    private static PlatilloAPI platilloAPI;
    private static PedidoAPI pedidoAPI;

    static{
        initClient();

    }
    private static void initClient(){

            Gson gson = new GsonBuilder ()
                    .registerTypeAdapter(Date.class, new DateSerializer ())
                    .registerTypeAdapter (Time.class, new TimeSerializer ())
                    .create ();

        retrofit = new Retrofit.Builder()
                .baseUrl (ipJeicy)
                .addConverterFactory (GsonConverterFactory.create (gson))
                .client (getClient())
                .build ();
    }

    public static OkHttpClient getClient(){


        HttpLoggingInterceptor loggin = new HttpLoggingInterceptor ();
        loggin.level (HttpLoggingInterceptor.Level.BODY);

        StethoInterceptor stetho = new StethoInterceptor ();
        OkHttpClient.Builder builder = new OkHttpClient.Builder ();

        builder.addInterceptor (loggin)
                .connectTimeout (60, TimeUnit.SECONDS)
                .readTimeout (60, TimeUnit.SECONDS)
                .writeTimeout (60, TimeUnit.SECONDS)
                .addNetworkInterceptor (stetho);
        return builder.build ();
    }

    public static void setToken(String value){
        token = value;
        initClient ();



    }

    public static UsuarioAPI getUsuarioAPI(){

        if(usuarioAPI == null){

            usuarioAPI = retrofit.create (UsuarioAPI.class);

        }
        return usuarioAPI;

    }

    public static ClienteAPI getClienteAPI(){
        if(clienteAPI == null){
            clienteAPI = retrofit.create (ClienteAPI.class);

        }
        return clienteAPI;
    }
    public static DocumentoAlmacenadoAPI documentoAlmacenadoAPI(){
        if(documentoAlmacenadoAPI == null){
            documentoAlmacenadoAPI = retrofit.create (DocumentoAlmacenadoAPI.class);

        }
        return documentoAlmacenadoAPI;
    }
    public static CategoriaAPI getCategoriaApi() {
        if (categoriaAPI == null) {
            categoriaAPI = retrofit.create(CategoriaAPI.class);
        }
        return categoriaAPI;
    }
    public static PlatilloAPI getPlatilloApi() {
        if (platilloAPI == null) {
            platilloAPI = retrofit.create(PlatilloAPI.class);
        }
        return platilloAPI;
    }
    public static PedidoAPI getPedidoApi(){
        if(pedidoAPI == null){
            pedidoAPI = retrofit.create(PedidoAPI.class);
        }
        return pedidoAPI;
    }

}
