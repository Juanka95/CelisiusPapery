package com.example.miaplicacion.communication;

public interface AnularPedidoCommunication {
    String anularPedido(int id);
}
