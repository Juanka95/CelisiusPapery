package com.example.miaplicacion.repository;

import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;

import com.example.miaplicacion.api.CategoriaAPI;
import com.example.miaplicacion.api.ConfigAPI;
import com.example.miaplicacion.entity.GenericResponse;
import com.example.miaplicacion.entity.service.Categoria;

import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class CategoriaRepository {

    private final CategoriaAPI api;
    private static CategoriaRepository repository;

    public CategoriaRepository() {
        this.api = ConfigAPI.getCategoriaApi();
    }
    public static CategoriaRepository getInstance(){
        if(repository == null){
            repository = new CategoriaRepository();
        }
        return repository;
    }
    public LiveData<GenericResponse<List<Categoria>>> listarCategoriasActivas(){
        final MutableLiveData<GenericResponse<List<Categoria>>> mld = new MutableLiveData<>();
        this.api.listarCategoriasActivas().enqueue(new Callback<GenericResponse<List<Categoria>>> () {
            @Override
            public void onResponse(Call<GenericResponse<List<Categoria>>> call, Response<GenericResponse<List<Categoria>>> response) {
                mld.setValue(response.body());
            }

            @Override
            public void onFailure(Call<GenericResponse<List<Categoria>>> call, Throwable t) {
                System.out.println("Error al obtener las categorías: " + t.getMessage());
                t.printStackTrace();
            }
        });
        return mld;
    }
}
