package com.example.miaplicacion.api;


import com.example.miaplicacion.entity.GenericResponse;
import com.example.miaplicacion.entity.service.DocumentoAlmacenado;

import okhttp3.MultipartBody;
import okhttp3.RequestBody;
import retrofit2.Call;
import retrofit2.http.Multipart;
import retrofit2.http.POST;
import retrofit2.http.Part;

public interface DocumentoAlmacenadoAPI {

    String base = "api/documento-almacenado";

    @Multipart
    @POST
    Call<GenericResponse<DocumentoAlmacenado>>save (@Part MultipartBody.Part file,
                                                    @Part("nombre") RequestBody requestBody);


}
