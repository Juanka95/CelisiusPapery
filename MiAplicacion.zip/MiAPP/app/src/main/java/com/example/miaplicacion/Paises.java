package com.example.miaplicacion;

public class Paises {

    private Integer id;
    private String nombre;
    private String paises;

    public Paises(Integer id, String nombre) {
        this.id = id;
        this.nombre = nombre;
    }

    public Paises() {
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    @Override
    public String toString(){
        this.paises = this.paises = id + " " + nombre +"";
        return paises;
    }

}
