package com.example.miaplicacion.communication;

public interface CarritoCommunication {

    void eliminarDetalle(int idP);

}
