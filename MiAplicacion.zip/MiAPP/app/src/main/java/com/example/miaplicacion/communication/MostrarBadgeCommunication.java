package com.example.miaplicacion.communication;

import com.example.miaplicacion.entity.service.DetallePedido;

public interface MostrarBadgeCommunication {

    void add(DetallePedido dp);

}
