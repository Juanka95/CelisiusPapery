package com.example.miaplicacion.api;

import com.example.miaplicacion.entity.GenericResponse;
import com.example.miaplicacion.entity.service.Cliente;

import retrofit2.Call;
import retrofit2.http.Body;
import retrofit2.http.POST;

public interface ClienteAPI {

    String base = "api/cliente";
    @POST
    Call<GenericResponse<Cliente>> guardarrCliente(@Body Cliente c);
}
