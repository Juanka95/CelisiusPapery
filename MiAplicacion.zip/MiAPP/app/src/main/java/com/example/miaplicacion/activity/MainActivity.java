package com.example.miaplicacion.activity;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.widget.ImageView;

import androidx.appcompat.app.AppCompatActivity;

import com.example.miaplicacion.R;
import com.example.miaplicacion.login;

public class MainActivity extends AppCompatActivity {

    ImageView lottie;

    private final int DURACION_SPLASH = 3000;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate (savedInstanceState);
        setContentView (R.layout.activity_main);


        lottie = findViewById (R.id.gif);


        lottie.animate().translationX(2000).setDuration(2000).setStartDelay (2900);
        new Handler ().postDelayed(new Runnable(){
            public void run(){
                Intent intent = new Intent(MainActivity.this, login.class);
                startActivity(intent);
                finish();
            };
        }, DURACION_SPLASH);
    }
}