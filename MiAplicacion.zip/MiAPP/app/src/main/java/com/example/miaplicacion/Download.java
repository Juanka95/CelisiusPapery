package com.example.miaplicacion;

import static java.lang.Thread.sleep;

import android.app.ProgressDialog;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;

public class Download extends AppCompatActivity {

    private TextView tvurl;
    private Button btnDownload;
    private String filepath = "https://drive.google.com/file/d/1Y9plIhX0wjvVUZU-q8qjMr_ACmV9TbR1/view?usp=sharing";
    private URL url = null;
    private String filename;
    @Override
    protected void onCreate(Bundle savedInstanceState){

        super.onCreate (savedInstanceState);
        setContentView (R.layout.item_mis_compras);

        tvurl = findViewById (R.id.txtValueCodPurchases);
        btnDownload = findViewById (R.id.btnExportInvoice);
        btnDownload.setOnClickListener (new View.OnClickListener () {
            @Override
            public void onClick(View view) {
                descargarPDF();
            }
        });
    }

    void descargarPDF(){
        String urlADescargar = "http://bibliotecadigital.ilce.edu.mx/Colecciones/ObrasClasicas/_docs/ElPrincipito.pdf";

        ProgressDialog progressDialog = new ProgressDialog (this);
        progressDialog.setIndeterminate (true);
        progressDialog.setProgressStyle (ProgressDialog.STYLE_HORIZONTAL);
        progressDialog.setMessage ("Descargando PDF...");

        new DescargarPDFAsynTask (progressDialog).execute (urlADescargar);

    }

    class DescargarPDFAsynTask extends AsyncTask<String, Integer, String> {

        ProgressDialog progressDialog;

        DescargarPDFAsynTask (ProgressDialog progressDialog){
            this.progressDialog = progressDialog;

        }

        @Override
        protected void onPreExecute() {

            super.onPreExecute ();
            progressDialog.show ();
        }

        @Override
        protected String doInBackground(String... urlPDF) {

            String urlADescargar = urlPDF[0];
            HttpURLConnection conexion = null;
            InputStream input = null;
            OutputStream output = null;

            try {
                URL url = new URL(urlADescargar);

                conexion = (HttpURLConnection) url.openConnection ();
                conexion.connect ();
                if (conexion.getResponseCode () != HttpURLConnection.HTTP_OK){
                    return "Conexion no realizada correctamente";
                }

                 input = conexion.getInputStream ();
                String rutaFichero = getFilesDir () + "/LibroCelisius.pdf";
                 output = new FileOutputStream (rutaFichero);

                 int tamanoFichero = conexion.getContentLength ();

                byte [] data = new byte[1024];
                int total = 0;
                int count;
                while ((count = input.read (data)) !=-1){
                    sleep(100);
                    output.write (data, 0, count);
                    total += count;
                    publishProgress ((int) (total * 100/tamanoFichero));
                }
            } catch (MalformedURLException e) {
                e.printStackTrace ();
                return "Error" + e.getMessage ();
            } catch (IOException e) {
                e.printStackTrace ();
                return "Error" + e.getMessage ();
            } catch (InterruptedException e) {
                e.printStackTrace ();
                return "Error" + e.getMessage ();
            } finally{
                try {
                if(input !=null) input.close ();
                 if(output != null) output.close ();
                 if(conexion != null) conexion.disconnect ();

                    } catch (IOException e) {
                        e.printStackTrace ();
                    }
                }




            return "Se ha realizado la descarga correctamente";
        }

        @Override
        protected void onProgressUpdate(Integer... values) {

            super.onProgressUpdate (values);
            progressDialog.setIndeterminate (false);
            progressDialog.setMax (100);
            progressDialog.setProgress (values[0]);
        }

        @Override
        protected void onPostExecute(String mensaje) {
            super.onPostExecute (mensaje);
            progressDialog.dismiss ();
            Toast.makeText (getApplicationContext (), mensaje, Toast.LENGTH_SHORT).show ();
        }
    }
}
