package com.example.miaplicacion.api;


import com.example.miaplicacion.entity.GenericResponse;
import com.example.miaplicacion.entity.service.Usuario;

import retrofit2.Call;
import retrofit2.http.Body;
import retrofit2.http.Field;
import retrofit2.http.FormUrlEncoded;
import retrofit2.http.POST;

public interface UsuarioAPI {

    //RUTA DEL CONTROLADOR USUARIO
    String base = "api/usuarios";


    //RUTA DEL CONTROLADOR USUARIO + LA RUTA DEL METODO
    @FormUrlEncoded
    @POST(base+"/login")
    Call<GenericResponse<Usuario>> login(@Field("email")String email, @Field ("pass") String contrasenia);

    @POST
    Call<GenericResponse<Usuario>> save(@Body Usuario u);
}