package com.example.miaplicacion.api;

import com.example.miaplicacion.entity.GenericResponse;
import com.example.miaplicacion.entity.service.Categoria;

import java.util.List;

import retrofit2.Call;
import retrofit2.http.GET;

public interface CategoriaAPI {

    String base = "api/categoria";

    @GET(base)
    Call<GenericResponse<List<Categoria>>> listarCategoriasActivas();
}
