package com.example.miaplicacion;

import java.io.Serializable;

public class ListElement implements Serializable {

    public int foto;
    public String nombre;
    public String autor;
    public String resumen;
    public String precio;

    public ListElement(int foto, String nombre, String autor, String resumen, String precio) {
        this.foto = foto;
        this.nombre = nombre;
        this.autor = autor;
        this.resumen = resumen;
        this.precio = precio;
    }



    public int getFoto() {
        return foto;
    }

    public void setFoto(int foto) {
        this.foto = foto;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getAutor() {
        return autor;
    }

    public void setAutor(String descripcion) {
        this.autor = autor;
    }

    public String getResumen() {
        return resumen;
    }

    public void setResumen(String resumen) {
        this.resumen = resumen;
    }

    public String getPrecio() {
        return precio;
    }

    public void setPrecio(String precio) {
        this.precio = precio;
    }
}
